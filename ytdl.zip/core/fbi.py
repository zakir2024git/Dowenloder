from yt_dlp import YoutubeDL
import traceback

def download_fbi(url, output_format="mp4", cookies_file=None):
    ydl_opts = {
        'format': 'best',  # This will choose the best available format without merging
        'outtmpl': './downloads/%(title)s.%(ext)s',
        'verbose': True,
    }

    try:
        with YoutubeDL(ydl_opts) as ydl:
            info_dict = ydl.extract_info(url, download=True)
            video_title = info_dict.get('title')
            video_size = info_dict.get('filesize', 'Unknown')
            download_path = ydl.prepare_filename(info_dict)

        return {
            'title': video_title,
            'size': video_size,
            'download_path': download_path
        }
    except Exception as e:
        print("Error occurred during download:")
        traceback.print_exc()
        return None

#download_fbi(url="https://www.facebook.com/share/r/EnytEAxf3FC8R36b/?mibextid=rS40aB7S9Ucbxw6v")
#download_fbi(url="https://www.instagram.com/reels/DBt8B1KSeLj")