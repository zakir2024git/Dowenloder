from pytubefix import YouTube
from yt_dlp import YoutubeDL

def read_srt(file_path):
    """Read an .srt subtitle file and return a list of lines."""
    with open(file_path, 'r', encoding='utf-8') as f:
        return f.readlines()

def write_srt(translated_lines, output_file_path):
    """Write translated lines to a new .srt file."""
    with open(output_file_path, 'w', encoding='utf-8') as f:
        f.writelines(translated_lines)

def get_cap(link, path="outplut"):
    yt = YouTube(link)
    caption = yt.captions.get('en')
    if caption != None:
        print("caption found")
        caption.save_captions(path+".srt")
    else:
        a = "caption not found "
        print(a)


def download_audio(link, cookies_file, proxy_url):
    """Download only the audio from a video and convert it to mp3 format."""
    ydl_opts = {
        'format': 'bestaudio',
        'outtmpl': 'downloads/audio_%(title)s.%(ext)s',
        'cookiefile': cookies_file,
        'proxy': proxy_url,
        'verbose': False,
    }

    with YoutubeDL(ydl_opts) as ydl:
        ydl.download([link])

# # Usage example:
# download_audio(
#     link="https://youtu.be/cLr4SLimX50",
#     cookies_file="path/to/cookies.txt",
#     proxy_url="http://your_proxy:port",
#     ffmpeg_path="C:/path/to/ffmpeg/bin"  # Change this to your ffmpeg location
# )
