from yt_dlp import YoutubeDL
from gpColor import colorize as c
from core import *

# Global options for yt-dlp
cookies_file = None or "token.txt" 
proxy_url = None

logo = """ ██████╗ ██████╗  █████╗ ███╗   ██╗██████╗ ██████╗  █████╗ 
██╔════╝ ██╔══██╗██╔══██╗████╗  ██║██╔══██╗██╔══██╗██╔══██╗
██║  ███╗██████╔╝███████║██╔██╗ ██║██║  ██║██████╔╝███████║
██║   ██║██╔══██╗██╔══██║██║╚██╗██║██║  ██║██╔═══╝ ██╔══██║
╚██████╔╝██║  ██║██║  ██║██║ ╚████║██████╔╝██║     ██║  ██║
 ╚═════╝ ╚═╝  ╚═╝╚═╝  ╚═╝╚═╝  ╚═══╝╚═════╝ ╚═╝     ╚═╝  ╚═╝"""


def youtube_search(query):
    """Perform YouTube search and display video titles and URLs."""
    print("Performing YouTube search...")
    ydl_opts = {
        'quiet': True,
        'default_search': 'ytsearch5',
        'cookiefile': cookies_file,  # Use cookies to authenticate session
        'proxy': proxy_url  # Use proxy if needed
    }
    with YoutubeDL(ydl_opts) as ydl:
        results = ydl.extract_info(query, download=False)
        for idx, video in enumerate(results['entries']):
            print(f"{idx + 1}. Title: {video['title']}")
            print(f"   URL: {video['webpage_url']}")
            print(f"   Duration: {video['duration']} sec")
    return results['entries']

def download_video(link, quality="high"):
    """Download video in specified quality."""
    ydl_opts = {
        'format': 'best' if quality == "high" else 'worst',
        'outtmpl': '%(title)s.%(ext)s',
        'cookiefile': cookies_file,  # Use cookies to authenticate session
        'proxy': proxy_url,  # Use proxy if needed
        'progress_hooks': [lambda d: print(f"Status: {d['status']}")],
    }
    with YoutubeDL(ydl_opts) as ydl:
        ydl.download([link])


def download_subtitles(link):
    """Download subtitles if available."""
    ydl_opts = {
        'writesubtitles': True,
        'subtitleslangs': ['en'],  # Adjust language code as needed
        'skip_download': True,
        'cookiefile': cookies_file,
        'proxy': proxy_url,
        'outtmpl': '%(title)s.%(ext)s',
    }
    with YoutubeDL(ydl_opts) as ydl:
        info_dict = ydl.extract_info(link, download=True)
        if 'requested_subtitles' in info_dict:
            print("Subtitle download complete.")
        else:
            print("No subtitles available.")

def download_playlist(link, quality="high"):
    """Download all videos in a playlist at the specified quality."""
    ydl_opts = {
        'format': 'best' if quality == "high" else 'worst',
        'outtmpl': '%(playlist_title)s/%(title)s.%(ext)s',
        'cookiefile': cookies_file,
        'proxy': proxy_url,
        'progress_hooks': [lambda d: print(f"Status: {d['status']}")],
    }
    with YoutubeDL(ydl_opts) as ydl:
        ydl.download([link])

def main():
    global cookies_file, proxy_url
    
    # User input for either cookies or proxy
    use_cookies = input("Do you want to use cookies? (y/n): ").strip().lower()
    if use_cookies == 'y':
        cookies_file = input("Enter the path to your cookies.txt file: ").strip()

    # use_proxy = input("Do you want to use a proxy? (y/n): ").strip().lower()
    # if use_proxy == 'y':
    #     proxy_url = input("Enter your proxy URL (e.g., http://proxyserver:port): ").strip()

    while True:
        import os

        try:
            os.system("clear")
        except:
            os.system("cls")

        print(c(logo, font="red", back="green"))
        print(c("YouTube Downloader          :)", font="black", back="white"))
        print(c("1. YouTube Search           :)", font="white", back="red"))
        print(c("2. Video Download (Low/High):)", font="white", back="red"))
        print(c("3. Audio Download           :)", font="white", back="red"))
        print(c("4. Subtitle Download (SRT)  :)", font="white", back="red"))
        print(c("5. Playlist Download        :)", font="white", back="red"))
        print(c("6. Facebook Download        :)", font="white", back="blue"))
        print(c("7. Insta Download           :)", font="#ffffff", back="#df73ff"))
        print("0. Exit")
        
        choice = str(input(c("Choose an option: ", font="white", back="yellow")))
        
        if choice == "1":
            query = input(" Enter search query: ")
            youtube_search(query)
        
        elif choice == "2":
            link = input(" Enter video link: ")
            quality = input("Choose quality (high/low): ").lower()
            download_video(link, quality)
        
        elif choice == "3":
            link = input(" Enter video link: ")
            download_audio(link, cookies_file, proxy_url)
        
        elif choice == "4":
            link = input(" Enter video link: ")
            download_subtitles(link)
        
        elif choice == "5":
            link = input(" Enter playlist link: ")
            quality = input("Choose quality for playlist videos (high/low): ").lower()
            download_playlist(link, quality)

        elif choice == "6":
            link = input(" Enter Video Link : ")
            download_fbi(link)
        
        elif choice == "7":
            link = input(" Enter Video Link : ")
            download_fbi(link)

        elif choice == "0":
            print(choice)
            print("Exiting application.")
            break

        elif choice == "exit":
            print(choice)
            print("Exiting application.")
            break

        else:
            print("Invalid choice. Please choose a valid option.")
        
        x = input("")

if __name__ == "__main__":
    main()
