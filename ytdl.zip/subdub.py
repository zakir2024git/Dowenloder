from deep_translator import GoogleTranslator
from tqdm import tqdm
import re
import time
import sys
from ytdl.core.gp_help import *

#read_srt(file_path)


def translate_subtitle(lines, src_lang='auto', dest_lang='bn'):
    """Translate subtitle lines using Google Translator with progress and animation."""
    translator = GoogleTranslator(source=src_lang, target=dest_lang)
    translated_lines = []
    
    # Initialize progress bar
    print("Translating subtitles...")
    for line in tqdm(lines, desc="Progress", unit=" lines"):
        if re.match(r'^\d{2}:\d{2}:\d{2},\d{3}', line):  # Timestamp lines
            translated_lines.append(line)
        elif line.strip().isdigit():  # Subtitle index numbers
            translated_lines.append(line)
        elif line.strip() == '':  # Blank lines
            translated_lines.append(line)
        else:
            # Animation for translation
            animation = "|/-\\"
            for _ in range(10):
                sys.stdout.write("\rTranslating... " + animation[_ % len(animation)])
                sys.stdout.flush()
                time.sleep(0.1)
            
            # Translate only the text lines
            translated_text = translator.translate(line.strip())
            translated_lines.append(translated_text + '\n')
    
    print("\nTranslation completed!")
    return translated_lines

#@write_srt(translated_lines, output_file_path)


# File paths
input_file_path = 'captions.srt'
output_file_path = 'output.srt'

# Process
lines = read_srt(input_file_path)
translated_lines = translate_subtitle(lines, src_lang='auto', dest_lang='en')
write_srt(translated_lines, output_file_path)

print("File saved as:", output_file_path)
