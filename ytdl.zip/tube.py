from pytubefix import Search, YouTube, Playlist
from pytubefix.cli import on_progress


def youtube_search(query, session=None):
    """Perform YouTube search and display video titles and URLs."""
    results = Search(query, session=session) if session else Search(query)
    for idx, video in enumerate(results.videos):
        print(f"{idx + 1}. Title: {video.title}")
        print(f"   URL: {video.watch_url}")
        print(f"   Duration: {video.length} sec")
    return results

def download_video(link, quality="high"):
    """Download a video in specified quality."""
    try:
        yt = YouTube(link, use_po_token=True)
        print(f"Downloading video: {yt.title}")
        stream = yt.streams.get_highest_resolution() if quality == "high" else yt.streams.get_lowest_resolution()
        stream.download()
        print("Video download complete.")
    except Exception as e:
        print(f"Error downloading video: {e}")

def download_audio(link):
    """Download only the audio from a video."""
    try:
        yt = YouTube(link, use_po_token=True)
        print(f"Downloading audio: {yt.title}")
        audio_stream = yt.streams.get_audio_only()
        audio_stream.download(filename_prefix="audio_")
        print("Audio download complete.")
    except Exception as e:
        print(f"Error downloading audio: {e}")

def download_subtitles(link):
    """Download subtitles if available."""
    try:
        yt = YouTube(link, use_po_token=True)
        if yt.captions:
            caption = yt.captions.get_by_language_code('en')
            if caption:
                subtitle_text = caption.generate_srt_captions()
                filename = yt.title.replace(" ", "_") + ".srt"
                with open(filename, "w", encoding="utf-8") as file:
                    file.write(subtitle_text)
                print("Subtitle download complete.")
            else:
                print("No subtitles available in the specified language.")
        else:
            print("No subtitles available for this video.")
    except Exception as e:
        print(f"Error downloading subtitles: {e}")

def download_playlist(link, quality="high"):
    """Download all videos in a playlist at the specified quality."""
    try:
        pl = Playlist(link, use_po_token=True)
        print(f"Downloading playlist: {pl.title}")
        for video in pl.videos:
            download_video(video.watch_url, quality=quality)
        print("Playlist download complete.")
    except Exception as e:
        print(f"Error downloading playlist: {e}")

def main():
    # Set up authenticated session if needed
    
    while True:
        print("\nYouTube Downloader")
        print("1. YouTube Search")
        print("2. Video Download (Low/High)")
        print("3. Audio Download")
        print("4. Subtitle Download (SRT)")
        print("5. Playlist Download")
        print("6. Exit")
        
        choice = input("Choose an option: ")
        
        if choice == "1":
            query = input("Enter search query: ")
            youtube_search(query)
        
        elif choice == "2":
            link = input("Enter video link: ")
            quality = input("Choose quality (high/low): ").lower()
            download_video(link, quality)
        
        elif choice == "3":
            link = input("Enter video link: ")
            download_audio(link)
        
        elif choice == "4":
            link = input("Enter video link: ")
            download_subtitles(link)
        
        elif choice == "5":
            link = input("Enter playlist link: ")
            quality = input("Choose quality for playlist videos (high/low): ").lower()
            download_playlist(link, quality)
        
        elif choice == "6":
            print("Exiting application.")
            break
        
        else:
            print("Invalid choice. Please choose a valid option.")

if __name__ == "__main__":
    main()
